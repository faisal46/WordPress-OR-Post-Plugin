;(function($) {
    $(document).ready(function() {

        $("#rtech_qr_toggle").click(function (e){
            $(this).toggleClass('toggleOn');
            ToggleOn =  $("#rtech_qr_toggle").attr('class');
            if(ToggleOn){
                $("#rtech_qr_toggle").val(1)
            }else{
                $("#rtech_qr_toggle").val(0)
            }

        });

    });
})(jQuery);