<?php
/*
Plugin Name: Post QR Code Generator
Plugin URI: www.rajtechbd.com
Description: Display QR Code Generator for every post below.
Version: 1.0
Author: RajTech
Author URI: www.faisal.rajtechbd.com
License: GPLv2 or later
Text Domain: rtech
Domain Path: /langusges/
*/
$rtech_countries = array(
    __('America','rtech'),
    __('Bangladesh','rtech'),
    __('Canada','rtech'),
    __('Denmark','rtech'),
    __('Indea','rtech'),
    __('Japan','rtech'),
    __('Pakistan','rtech'),
    __('Nepal','rtech'),
);
function rtech_init(){
    global $rtech_countries;
    $rtech_countries = apply_filters('rtech_countries_list', $rtech_countries);
}
add_action('init','rtech_init');
function rtech_load_text_domain(){
    load_textdomain('rtech', false, dirname(__FILE__) . "/languages");
}
add_action('plugins_loaded', 'rtech_load_text_domain');

function rtech_display_qr_code( $content ){
    $current_post_id = get_the_ID();
    $current_post_title = get_the_title($current_post_id);
    $current_post_url = urlencode(get_the_permalink($current_post_id));
    $current_post_type = get_post_type($current_post_id);

    // Post Type Check
    $post_type_check = apply_filters('rtech_post_type_check', array());
    if( in_array($current_post_type, $post_type_check) ){
        return $content;
    }

    // Dimension Hook
    $height = get_option('rtech_qr_height');
    $width = get_option('rtech_qr_width');
    $height = $height ? $height : 200;
    $width = $width ? $width : 200;
    $dimension = apply_filters( 'rtech_qr_dimention', "{$width}x{$height}" );

    //Image Attributes
    $image_attributes = apply_filters('pqrc_image_attributes',null);

    $image_src = sprintf( 'https://api.qrserver.com/v1/create-qr-code/?size=%s&data=%s', $dimension, $current_post_url );
    $content .= sprintf("<div class='qrcode'><img %s  src='%s' alt='%s' /></div>",$image_attributes, $image_src, $current_post_title);
    return $content;

}
add_filter("the_content", "rtech_display_qr_code");

function rtech_setting_init(){
    add_settings_section('rtech_qr_section', __('Post to QR Code','rtech'), 'rtech_qr_section_callback', 'general');
//    add_settings_field('rtech_qr_height', __('QR Code Height','rtech'), 'rtech_qr_display_height', 'general','rtech_qr_section');
//    add_settings_field('rtech_qr_width', __('QR Code Width','rtech'), 'rtech_qr_display_width', 'general','rtech_qr_section');
    add_settings_field('rtech_qr_height', __('QR Code Height','rtech'), 'rtech_qr_display_field', 'general','rtech_qr_section',array('rtech_qr_height'));
    add_settings_field('rtech_qr_width', __('QR Code Width','rtech'), 'rtech_qr_display_field', 'general','rtech_qr_section',array('rtech_qr_width'));
    add_settings_field('rtech_qr_select', __('Dropdown','rtech'), 'rtech_qr_display_select_field', 'general','rtech_qr_section');
    add_settings_field('rtech_qr_checkbox', __('Select Checkbox','rtech'), 'rtech_qr_display_checkbox_field', 'general','rtech_qr_section');
    add_settings_field('rtech_qr_toggle', __('Toggle','rtech'), 'rtech_qr_display_toggle_field', 'general','rtech_qr_section');

    register_setting('general','rtech_qr_height',array('sanitize_callback' => 'esc_attr'));
    register_setting('general','rtech_qr_width',array('sanitize_callback' => 'esc_attr'));
    register_setting('general','rtech_qr_select',array('sanitize_callback' => 'esc_attr'));
    register_setting('general','rtech_qr_checkbox');
    register_setting('general','rtech_qr_toggle');
}
function rtech_qr_display_toggle_field(){
    $option = get_option('rtech_qr_toggle');
    if($option == '1'){
        echo '
      <label class="switch">
          <input type="checkbox" name="rtech_qr_toggle" id="rtech_qr_toggle" value="'.$option.'"/>
          <span class="slider round"></span>
      </label>';
    }else{
        echo '
      <label class="switch">
          <input type="checkbox" name="rtech_qr_toggle" id="rtech_qr_toggle" value="'.$option.'"/>
          <span class="slider round"></span>
      </label>';
    }

}
function rtech_qr_display_checkbox_field(){
    global $rtech_countries;
    $option = get_option('rtech_qr_checkbox');
    foreach ($rtech_countries as $country){
        $selected = '';
        if(is_array($option) && in_array($country, $option)){
            $selected = 'checked';
        }
    printf('<input type="checkbox" name="rtech_qr_checkbox[]" value="%s" %s> %s<br>', $country, $selected, $country  );
    }
    echo "</select>";
}
function rtech_qr_display_select_field(){
    global $rtech_countries;
    $option = get_option('rtech_qr_select');
    printf('<select id="%s" name="%s">', 'rtech_qr_select', 'rtech_qr_select');
    foreach ($rtech_countries as $country){
    $selected = '';
      if($option == $country) {
        $selected = 'selected';
      }
    printf('<option value="%s" %s>%s</option>', $country, $selected, $country );
    }
    echo "</select>";
}
function rtech_qr_display_field($args){
    $option = get_option($args[0]);
    printf('<input type="text" id="%s" name="%s" value="%s"/>', $args[0], $args[0], $option);
}
function rtech_qr_section_callback(){
   echo "<p>".__('Setting for Post to QR code plugin area.','rtech')."</p>";
}
//function rtech_qr_display_height(){
//    $height = get_option('rtech_qr_height');
//    printf('<input type="text" id="%s" name="%s" value="%s"/>', 'rtech_qr_height', 'rtech_qr_height', $height);
//}
//function rtech_qr_display_width(){
//    $width = get_option('rtech_qr_width');
//    printf('<input type="text" id="%s" name="%s" value="%s"/>', 'rtech_qr_width', 'rtech_qr_width', $width);
//}

add_action("admin_init", 'rtech_setting_init');

function rtech_assets($screen){
    if('options-general.php' == $screen){
        wp_enqueue_style('rtech-style-css', plugin_dir_url(__FILE__)."/assets/css/style.css");
        wp_enqueue_script('rtech-main-js', plugin_dir_url(__FILE__)."/assets/js/rtech-rtech-main.js", array('jquery'), time(), true);
    }
}
add_action('admin_enqueue_scripts', 'rtech_assets');